#define _CRT_SECURE_NO_WARNINGS // Used to enable some features of the visual studio
#include "HashTable.h"
#include "Bucket.h"
#include<assert.h>
#include<stdlib.h>
#include<stdio.h>


// Used to mark a free space in the Hashtable


/* This function takes a key and returns an index
 i.e. an index to the Hashtable array */
static int hash(Key key, int tablesize)
{
	return -1;
}

/* Look forward to the principle of open addressing (rehashing). The number of collisions is returned via the pointer col in the parameter list */

static int linearProbe(const HashTable* htable, Key key, unsigned int *col)
{
    return -1; // Replaced with an index
}

/* Allocate memory for the hash table */
HashTable createHashTable(unsigned int size)
{
    // These two lines are only used to compile the project. Replace them using appropriate code.
    HashTable htable = { 0 };
    return htable;
}

/* Inserts the {key, data} pair in the Hashtable, if a key already exists, update its value by data.
   Returns 1 if there is a collision, otherwise return 0 */
unsigned int insertElement(HashTable* htable, const Key key, const Value value)
{
	// Postcondition: There is an element for the key in the table (use lookup () to verify)
    return 0; // Replaced with the proper return value as specified above.
}

/* Delete data with key "key" */
void deleteElement(HashTable* htable, const Key key)
{
	// Postcondition: No element with key is in the table (use loookup () to verify)
}

/* Return a pointer to the data/record that the key represents, or return NULL if no such key exists */
const Value* lookup(const HashTable* htable, const Key key)
{
    return NULL; // Replace with the proper return value
}


/* Free the memory used by the Hashtable */
void freeHashTable(HashTable* htable)
{
    // Postcondition: The hash table has a size of 0
}

/* Returns the size of the Hashtable */
unsigned int getSize(const HashTable* htable)
{
    return 0; // Replace with the proper return value
}

/* This should print the hash table to easily visualize it */
void printHashTable(const HashTable* htable)
{
    // Tips: use printPerson() in Person.h to print a person
}
