#define _CRT_SECURE_NO_WARNINGS // Used to enable some features of the visual studio
#include "Person.h"
#include<assert.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

static void getRandomName(char* name)
{
	assert(name != NULL);

	char* names[] = { "Stefan", "Anna" , "Aram", "Sture", "Johan", "Jasmin", "Alva", "Nora", "Emma", "Linnea", "Lena", "Johanna",
		"Moa", "Per", "Alex", "Fredrik", "Kent", "Ibrahim", "Malin", "Sara", "Ida", "Hanna", "Sixten", "Birger" };

	const int numberOfNames = sizeof(names) / sizeof(char*);
	int index = rand() % numberOfNames;
	strcpy(name, names[index]);
}

static int getRandomPersonalNumber(void)
{
	int day = rand() % 30 + 1; // For the sake of simplicity, we assume that months have 30 days (will have some nonexistent dates in February, but it's not important)
	int month = rand() % 12 + 1;
	int year = rand() % 60 + 40;
	return day + 100 * month + 10000 * year;
}

Person getRandomPerson(void)
{
	Person randomPerson;
	getRandomName(randomPerson.name);
	randomPerson.personalNumber = getRandomPersonalNumber();
	randomPerson.weight = (float)(rand() % 70 + 50);
	return randomPerson;
}

void printPerson(Person* personToPrint, int index)
{
    printf("%d --- %d: %s, weight: %f ", index, personToPrint->personalNumber, personToPrint->name, personToPrint->weight);
}
