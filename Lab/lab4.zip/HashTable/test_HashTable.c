#define _CRT_SECURE_NO_WARNINGS // Used to enable some features of the visual studio
#include "HashTable.h"

#include <assert.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "Person.h"
#define SIZE 50
#define LOOPS 1000

/* Types for handling a dynamic number of tables */
typedef struct{
    HashTable table;
    int tableSize;
    int colissions;
}Table;

typedef struct{
    Table *Tables;
    int noOfTables;
}HTables;

static void fillArrayWithPersons(Person *list);
static int addPersonsToTable(HashTable *htable, Person *persons);
static int getTableSize(int nr);

/* Testfunctions */
void compareHashTableSizes(void);/* Choose how many hashtable with different table sizes you want to compare. Sets the same data in all sizes and prints the number of collisions with the respective size */
void test(void); /* Tests all functions and different collisions for the hash table. */
void menu(void); /*A menu to test your functions with manual data or random data*/


int main(void)
{
    //menu();
    test();
    //compareHashTableSizes();

	return 0;
}

/*********************************************************************************************************/
/* Functions for menu, test function and for comparing collisions for different sizes on the hash table */
/*********************************************************************************************************/

static void fillArrayWithPersons(Person *list)
{
    for(int i = 0; i < SIZE; i++)
        list[i] = getRandomPerson();
}

static int addPersonsToTable(HashTable *htable, Person *persons)
{
    int colissions = 0;
    for(int i = 0; i < SIZE; i++)
    {
        colissions+=insertElement(htable, persons[i].personalNumber, persons[i]);
        assert(lookup(htable, persons[i].personalNumber)->personalNumber == persons[i].personalNumber);
    }
    return colissions;
}

static int getTableSize(int nr)
{
    int tableSize;
    if(nr <= 0)
    do
    {
        printf("Size of hashtable: ");
        scanf("%u", &tableSize); // It is unnecessary to let the size be a prime
    } while (tableSize > 0);
    else{
        do
        {
            printf("Size of hashtable %d (at least %d): ", nr, SIZE);
            scanf("%u", &tableSize); //It is unnecessary to let the size be a prime
        } while (tableSize < SIZE);
        }
    return tableSize;
}



/* Choose how many hashtable with different table sizes you want to compare. Insert the same data in all tables and prints the number of collisions with the respective size */
void compareHashTableSizes(void)
{
    unsigned int noOfTables;
    HTables myTables;
    int i, j;
    
    printf("How many hashtables do you want to compare: ");
    scanf("%d", &noOfTables);
    
    myTables.Tables = (Table *)calloc(noOfTables, sizeof(Table));
    if(myTables.Tables == NULL)
    {
        printf("Error creating tables, shutting down\n");
        return;
    }
    
    for(j = 0; j < noOfTables; j++)
    {
        myTables.Tables[j].tableSize = getTableSize(j+1);
        assert(myTables.Tables[j].tableSize >= SIZE);
        myTables.Tables[j].colissions = 0;
    }
    
    Person listOfPersons[SIZE];
    
    for(i = 0; i < LOOPS; i++)
    {
        fillArrayWithPersons(listOfPersons); //fills array
        
        for(j = 0; j < noOfTables; j++)
        {
            myTables.Tables[j].table = createHashTable(myTables.Tables[j].tableSize);
            myTables.Tables[j].colissions += addPersonsToTable(&(myTables.Tables[j].table), listOfPersons);
            freeHashTable(&(myTables.Tables[j].table));
        }
    }
    
    for(j = 0; j < noOfTables; j++)
        printf("Table %d (size %d) - number of collisions: %d\n", j+1, myTables.Tables[j].tableSize, myTables.Tables[j].colissions/LOOPS);
    
    
    free(myTables.Tables);
}




/* Tests all functions and different cases for the hash table. You can add a call to printHashTable (& htable) at any time; to see how the hashtable looks like*/
void test(void)
{
    HashTable htable = createHashTable(10);
    assert(getSize(&htable) == 10);
    Person arrPersons[9] = {{931014, 81.0, "Tobias"},
                            {881011, 75.0, "Alva"},
                            {600704, 114.0, "Bengt"},
                            {790408, 93.5, "Nora"},
                            {900610, 71.3, "Aram"},
                            {510929, 83.6, "Jasmin"},
                            {740318, 63.0, "Emma"},
                            {801204, 93.4, "Ibrahim"},
                            {830709, 53.9, "Sara"}};
    Person aPerson;
    const Value *aPersonPointer;
    int i;
    
    //add some people and make sure they are in the right place
    for(i = 0; i < 9; i++)
    {
        insertElement(&htable, arrPersons[i].personalNumber, arrPersons[i]);
    }
    assert(htable.table[0].key == 900610);
    assert(htable.table[1].key == 881011);
    assert(htable.table[2].key == 740318);
    assert(htable.table[3].key == 830709);
    assert(htable.table[4].key == 931014);
    assert(htable.table[5].key == 600704);
    assert(htable.table[6].key == 801204);
    assert(htable.table[7].key == UNUSED);
    assert(htable.table[8].key == 790408);
    assert(htable.table[9].key == 510929);
    assert(collisions == 11);;
    
    //add duplicate key, value to be updated
    strcpy(aPerson.name, "Anna");
    aPerson.personalNumber = 881011;
    aPerson.weight = 65.2;
    insertElement(&htable, 881011,aPerson);
    assert(htable.table[1].value.weight == aPerson.weight);
    assert(strcmp(htable.table[1].value.name, aPerson.name) == 0);
    
    //Looking for a person in the right place and the person who is in another place because of a collision
    aPersonPointer = lookup(&htable, 790408);
    assert(strcmp(aPersonPointer->name, "Nora") == 0);
    aPersonPointer = lookup(&htable, 740318);
    assert(strcmp(aPersonPointer->name, "Emma") == 0);
    
    //Looking for someone who is not in the table
    assert(lookup(&htable, 600705) == NULL);
    

    //Remove a person with the given key
    deleteElement(&htable, 801204);
    assert(lookup(&htable, 801204) == NULL);
    assert(htable.table[6].key == UNUSED);
    
    //Remove a person who has the following key
    deleteElement(&htable, 790408);
    assert(lookup(&htable, 790408) == NULL);
    assert(htable.table[0].key == 900610);
    assert(htable.table[1].key == 881011);
    assert(htable.table[2].key == 830709);
    assert(htable.table[3].key == UNUSED);
    assert(htable.table[4].key == 931014);
    assert(htable.table[5].key == 600704);
    assert(htable.table[6].key == UNUSED);
    assert(htable.table[7].key == UNUSED);
    assert(htable.table[8].key == 740318);
    assert(htable.table[9].key == 510929);
    
    //Empty the entire hash table
    deleteElement(&htable, 900610);
    deleteElement(&htable, 881011);
    deleteElement(&htable, 830709);
    deleteElement(&htable, 931014);
    deleteElement(&htable, 600704);
    deleteElement(&htable, 740318);
    deleteElement(&htable, 510929);
    assert(htable.table[0].key == UNUSED);
    assert(htable.table[1].key == UNUSED);
    assert(htable.table[2].key == UNUSED);
    assert(htable.table[3].key == UNUSED);
    assert(htable.table[4].key == UNUSED);
    assert(htable.table[5].key == UNUSED);
    assert(htable.table[6].key == UNUSED);
    assert(htable.table[7].key == UNUSED);
    assert(htable.table[8].key == UNUSED);
    assert(htable.table[9].key == UNUSED);
    
    //Add more info
    insertElement(&htable, arrPersons[0].personalNumber, arrPersons[0]);
    assert(htable.table[4].key == 931014);
    insertElement(&htable, arrPersons[1].personalNumber, arrPersons[1]);
    assert(htable.table[1].key == 881011);
    insertElement(&htable, arrPersons[2].personalNumber, arrPersons[2]);
    assert(htable.table[5].key == 600704);
    insertElement(&htable, arrPersons[3].personalNumber, arrPersons[3]);
    assert(htable.table[8].key == 790408);
    
    //Deallocate memory and release the table
    freeHashTable(&htable);
    assert(htable.size == 0);
    assert(htable.table == NULL);
    
    
    printf("Your hashtable passed the test\n\n");
}

void menu(void)
{
    int choice, subChoice, size, pNr;
    HashTable htable;
    Person aPerson;
    const Value *aPersonPointer;
    do{
        printf("\n----------Menu Hashtable----------\n1 - Create Hashtable\n2 - Insert element\n3 - Print hashtable\n4 - Search for element\n5 - Delete element\n6 - Get size of hashtable\n7 - Free hashtable\n8 - Exit\n");
        scanf("%d", &choice);
        
        switch (choice)
        {
            case 1:
                size = getTableSize(0);
                htable = createHashTable(size);
                break;
            case 2:
                printf("1 - Random data\n2 - Manual data\n");
                scanf("%d", &subChoice);
                switch (subChoice) {
                    case 1:
                        aPerson = getRandomPerson();
                        printf("Random\n%d: %s: %f\n", aPerson.personalNumber, aPerson.name, aPerson.weight);
                        break;
                    case 2:
                        while(getchar()!='\n');
                        printf("Enter name: ");
                        fgets(aPerson.name, 28, stdin);
                        aPerson.name[sizeof(aPerson.name-1)] = '\0'; //remove the entry as fgets reads into the string - ignore potential warning message
                        printf("Enter weight: ");
                        scanf("%f", &aPerson.weight);
                        printf("Enter personal number (YYMMDD): ");
                        scanf("%d", &aPerson.personalNumber);
                        break;
                    default: printf("Invalid input\n");
                        break;
                }
                
                if(insertElement(&htable, aPerson.personalNumber, aPerson) == 1)
                    printf("Colission!!!\n");
                
                break;
            case 3:
                printHashTable(&htable);
                break;
            case 4:
                printf("Enter personal number (YYMMDD) to search for: ");
                scanf("%d", &pNr);
                aPersonPointer = lookup(&htable, pNr);
                if(aPersonPointer == NULL)
                    printf("%d could not be found in the table\n", pNr);
                else
                    printf("Found\n%d: %s: %f\n", aPersonPointer->personalNumber, aPersonPointer->name, aPersonPointer->weight);
                break;
            case 5:
                printf("Enter personal number (YYMMDD) to delete: ");
                scanf("%d", &pNr);
                deleteElement(&htable, pNr);
                break;
            case 6:
                printf("Table size: %d\n\n", getSize(&htable));
                break;
            case 7:
                freeHashTable(&htable);
                break;
                
            default: printf("Invalid input\n");
                break;
        }
        
    }while(choice != 8);
}


