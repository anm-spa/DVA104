#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "Bucket.h"
#define UNUSED 0

/* Hashtable that resolves collisions using open addressing */

typedef struct 
{
    struct Bucket* table; // The Hashtable is an array of Buckets
    unsigned int size; // Size of the Hashtable
} HashTable;

/* Allocates memory for the hash table */
HashTable createHashTable(unsigned int size);

/* Inserts the {key, data} pair in the Hashtable, if a key already exists, the corresponding data should be modified. Returns 1 if collision occurs, otherwise return 0 */
unsigned int insertElement(HashTable* htable, const Key key, const Value value);

/* Removing data with key "key" */
void deleteElement(HashTable* htable, const Key key);

/* Returns a pointer to the value associated with the key if item is found; otherwise returns NULL*/
const Value* lookup(const HashTable* htable, const Key key);

/* Free memory allocated for the hash table */
void freeHashTable(HashTable* htable);

/* Returns the size of the hash table */
unsigned int getSize(const HashTable* htable);

/* Print the hash table */
void printHashTable(const HashTable* htable); 

#endif
