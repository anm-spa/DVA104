
/* Stack */

#ifndef STACK_H
#define STACK_H
#include "list.h"


/*******************************************************************/
/* Stack could be implemented as a linked list                     */
/* Reuse the functions written for the linked list                 */
/* OBS! Do not change the interface                                */
/* All functions must be implemented                               */
/*******************************************************************/
 
typedef List Stack;     // Ordet 'Stack' kommer att vara din listtyp


/* Create a new empty stack */
Stack initializeStack(void);

/* Return 1 if the stack is empty, otherwise 0 */
int stackIsEmpty(const Stack stack);

/* Add an item to the stack */
void push(Stack* pStack, const Data element);

/* Remove an item from the top of the stack */
void pop(Stack* pStack);

/* Return the item on the top of the stack */
Data peekStack(const Stack stack);

/*Print the stack items (used for testing and debugging) */
void printStack(const Stack stack, FILE *textfile);


#endif
