#include "queue.h"
#include<assert.h>

/*
It's important to reuse the code that you have already written for the list. This does not mean that you copy the code, reuse it by calling the functions already implemented.
*/

/*Function is ready*/
Queue initializeQueue(void)
{
    return NULL;
}

int queueIsEmpty(const Queue queue)
{
    return 0;
}

/*Postcondition: data is added as last in the queue*/
void enqueue(Queue* queue, const Data data)
{

}

/* Precondition: queue is not empty */
void dequeue(Queue* queue)
{

}

/* Precondition: queue is not empty */
Data peekQueue(const Queue queue)
{
    return 0;
}


/* Used for testing and debug */
void printQueue(const Queue queue, FILE *textfile)
{

}


