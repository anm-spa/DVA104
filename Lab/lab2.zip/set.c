#include "Set.h"
#include <assert.h>

/*Function is ready*/
Set initializeSet(void)
{
	return createEmptyList();
}

/* Tips: you cannot add an item if it is already in the list (check it first)
   Postcondition: 'element' is in the list (tips, use the isInSet function) */
void addToSet(Set* set, const Data element)
{
        
}

/* Postcondition: 'element' is NOT in the list (tips, use the isInSet function) */
void removeFromSet(Set* set, const Data element)
{
    
}

int isInSet(const Set set, const Data element)
{
    return 0;
}

void printSet(const Set set, FILE *textfile)
{
    
}

