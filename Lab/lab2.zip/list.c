#include "list.h"
#include <stdlib.h>
#include <assert.h>

//Auxiliary function for allocating memory for a new node and initializing it with data.
static struct Node* createListNode(const Data data)
{
	return NULL;
}

List createEmptyList(void)
{
	return NULL;
}

/*
Return 1 is the list is empty, otherwise 0
*/
int isEmpty(const List list)
{
    return 0;
}

/*
Add an item at the beginning of the list
*/
void addFirst(List *list, const Data data)
{
    //Use createListNode to create a new node
    //Note list could be empty as well as already have at least one node
}

/*
Add an item at the end of the list
*/
void addLast(List *list, const Data data)
{

}

/*
Remove the last item from the list
*/
void removeFirst(List *list)
{
	//Precondition: list is not empty (assert)
	//Do NOT forget to free the memory
   //Think that after this operation the rest of the list must be still reachable
}

/*
Remove the last item from the list
*/
void removeLast(List *list)
{
	//Precondition: list is not empty (assert)
	//Do NOT forget to free the memory
   //Think that after this operation the rest of the list must be still reachable
}

/*
Remove the first occurrence of a value in the list
Return 1 if the value is found, otherwise 0
Tips: once you have found the value, you can reuse one of the previous functions to remove it
*/
int removeElement(List *list, const Data data)
{
    return 0;
}

/*
Return 1 if the data is stored in the list
*/
int search(const List list, const Data data)
{
    return 0;
}

/*
Count the number of elements in the list
*/
int numberOfNodesInList(const List list)
{
    return 0;
}

/*
Remove all items from the list and free the memory
*/
void clearList(List *list)
{
    
}

/*
Print the list on the screen or into a file. To this end use fprintf() and specifies stdout to get the result on the screen
*/
void printList(const List list, FILE *textfile)
{

}

/*
Return the first item in the list
Precondition: list is not empty (test with assert)
*/
Data getFirstElement(const List list)
{
    return 0;
}

/*
Return the last item in the list
Precondition: list is not empty (test with assert)
*/
Data getLastElement(const List list)
{
    return 0;
}
