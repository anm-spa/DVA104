#ifndef LIST_H
#define LIST_H

#include <stdio.h>

typedef int Data;

//#define DOUBLE_LINKED_LIST

struct Node
{
	Data data;
	#ifdef DOUBLE_LINKED_LIST
	struct Node *prev;
	#endif
	struct Node *next;
};

//List is represendet as a Node pointer
typedef struct Node *List;

//Return an empty list
List createEmptyList(void);

//Return 1 if lis is empty, otherwise 0
int isEmpty(const List list);

//Add data in front to the list
void addFirst(List *list, const Data data);

//Add data to the list as the first node
void addLast(List *list, const Data data);

//remove the first node in the list
void removeFirst(List *list);

//remove the last node in the list
void removeLast(List *list);

//remove the first node in the list having data equal to target and return 1, otherwise (if it does not exists) return 0
int removeElement(List *list, const Data target);

//search data in the list, return 1 is it occurs, 0 otherwise
int search(const List list, const Data data);

//return the number of nodes stored in the list
int numberOfNodesInList(const List list);

//delete all nodes from the lilst
void clearList(List *list);

//print the list
void printList(const List list, FILE *textfile);

//return the data stored in the first node of the list
Data getFirstElement(const List list);

//return the data stored in the last node of the list
Data getLastElement(const List list);

#endif
