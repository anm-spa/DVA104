/* Set */

#ifndef SET_H
#define SET_H
#include "list.h" 

/*******************************************************************/
/* Set could be implemented as a linked list                       */
/* Reuse the functions written for the linked list                 */
/* OBS! Do not change the interface                                */
/* All functions must be implemented                               */
/*******************************************************************/

typedef List Set; 

/* Create a new empty set */
Set initializeSet(void);

/*Add an item into the set (it must be unique) */
void addToSet(Set* set, const Data element);

/*Remove an item from the set (if existing)*/
void removeFromSet(Set* set, const Data element);

/*Returns 1 if an item is in the set, otherwise 0 */
int isInSet(const Set set, const Data element);

/*Print the set items (used for testing and debugging) */
void printSet(const Set set, FILE *textfile);


#endif
