#include "Stack.h"
#include<assert.h>

/*Function is ready*/
Stack initializeStack(void)
{
    return createEmptyList();
}

int stackIsEmpty(const Stack stack)
{
    return 0;
}

/* Postcondition 'data' is in the first position of the stack */
void push(Stack* stack, const Data data)
{
    
}

/* Precondition: stack cannot be empty */
void pop(Stack* stack)
{
    
}

/* Precondition: stack cannot be empty */
Data peekStack(const Stack stack)
{
     return 0; // Ersatt denna rad med ratt returvarde
}

/* Print the all the items (used for testing and debugging) */
void printStack(const Stack stack, FILE *textFile)
{
    
}
