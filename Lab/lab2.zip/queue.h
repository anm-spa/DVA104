/* Queue */

#ifndef QUEUE_H
#define QUEUE_H

#include "list.h"

/*******************************************************************/
/* Queue could be implemented as a linked list                     */
/* Reuse the functions written for the linked list                 */
/* OBS! Do not change the interface                                */
/* All functions must be implemented                               */
/*******************************************************************/

typedef List Queue;  // Ordet 'Queue' kommer att vara din listtyp


/* create an empty queue */
Queue initializeQueue(void);

/* Return 1 if the queue is empty, otherwise 0 */
int queueIsEmpty(const Queue queue);

/* Push an item into the queue */
void enqueue(Queue* queue, const Data data);

/* Remove an item from the queue */
void dequeue(Queue* queue);

/* Returne the first item in the queue */
Data peekQueue(const Queue queue);

/*Print the queue */
void printQueue(const Queue queue, FILE *textfile);

#endif
