#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <math.h>
#include "BSTree.h"


/* Static functions are used by other functions in the tree and should not be in the interface */

/* Creates a tree with the given data by allocating memory for the node. Do not forget to initialize the pointers! */
static struct treeNode* createNode(int data)
{
    // Do not forget to test if the allocation succeeded
	return NULL; // To be replaced with the correct return value

/* Returns a dynamically assigned array that contains the tree data sorted */
static int* writeSortedToArray(const BSTree tree)
{
    /* Create a dinamic array of the right size.
       Write data from the tree into the array (sorted in ascending order).
       You maybe need an auxiliar function here  */

    return NULL; // To be replaced with the correct return value
}

/* Build a balanced tree from the sorted array */
static void buildTreeSortedFromArray(BSTree* tree, const int arr[], int size)
{
    /* Build it recursively. Start by choosing the element in the middle of the array as root. Repeat on the left and right part of the array for the left- and right-subtree, respectively. */
}


/* Implementation of the tree interface */

/* Create an empty tree */
BSTree emptyTree(void)
{
	return NULL;
}

/* Return 1 if the tree is empty, 0 otherwise */
int isEmpty(const BSTree tree)
{
	return -1; // To be replaced with the correct return value
}

/* Place data correctly in the BST
 Post-condition: data belongs to the tree */
void insertSorted(BSTree* tree, int data)
{
	/* Think that tree could be empty.
      Post-condition can be verified with help of the find(...) function */
}

/* Print Functions:
   Use stdout as second argument to print on the screen. It is enough that you implement LR schema*/
void printPreorder(const BSTree tree, FILE *textfile)
{

}

void printInorder(const BSTree tree, FILE *textfile)
{

}

void printPostorder(const BSTree tree, FILE *textfile)
{

}

/* Return 1 if belongs to the tree, 0 otherwise */
int find(const BSTree tree, int data)
{
    // Think that tree could be empty.
	return -1; //To be replaced with the correct return value
}

/* Remove data from the tree (if it exists) */
void removeElement(BSTree* tree, int data)
{
	/* Think that tree could be empty.
		Mind the three cases: a leaf (no children), one child (left or right), two children

		Do not forget Do not forget to free the node removed*/
}

/* Return the number of nodes stored in the tree */
int numberOfNodes(const BSTree tree)
{
	return -1; //To be replaced with the correct return value
}

/* Return the depth of the tree: the number of nodes along the longest path from the root node down to the farthest leaf node. */
int depth(const BSTree tree)
{
	return -1; //To be replaced with the correct return value
}

/* Return minimum depth of the tree (you could need to include "math.h").  The minimum depth is the number of nodes along the shortest path from root node down to the nearest leaf node. */
int minDepth(const BSTree tree)
{
	return -1; //To be replaced with the correct return value
}

/* Balance the tree */
void balanceTree(BSTree* tree)
{
	/* Suggestions for the algorithm:
		- Build the sorted array corresponding to the tree with writeSortedToArray()
		- Empty the tree with freeTree()
		- Build the tree recursively from the array with buildTreeSortedFromArray()
		- Free memory for the dynamically allocated array

	   Post-conditions:
	   - tree have the same nodes as before
}

/* Emprty the tree (and free the memory... of course) */
void freeTree(BSTree* tree)
{
	// Post-condition: tree is empty
}


