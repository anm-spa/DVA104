#ifndef BSTREE_H
#define BSTREE_H

#include <stdio.h>

struct treeNode
{
	int data;
	struct treeNode* left;
	struct treeNode* right;
};

typedef struct treeNode* BSTree;

/* Create an empty tree */
BSTree emptyTree(void);

/* Return 1 is the tree is empty, 0 otherwise */
int isEmpty(const BSTree tree);

/* Put data in the correct (i.e., sorted) position in *tree */
void insertSorted(BSTree* tree, int data);

/* Print Functions */
void printPreorder(const BSTree tree, FILE *textfile);
void printInorder(const BSTree tree, FILE *textfile);
void printPostorder(const BSTree tree, FILE *textfile);

/* Return 1 if data belongs to tree, 0 otherwise */
int find(const BSTree tree, int data);

/* Remove data from the tree if it exists */
void removeElement(BSTree* tree, int data);

/* Return the number of nodes in the tree */
int numberOfNodes(const BSTree tree);

/* Return tree depth */
int depth(const BSTree tree);

/* Return min-depth of the tree */
int minDepth(const BSTree tree);

/* Balance th tree */
void balanceTree(BSTree* tree);

/* Empty the tree and free the mem */
void freeTree(BSTree* tree);

#endif
