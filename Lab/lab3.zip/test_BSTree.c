#include <assert.h>
#include "BSTree.h"
#include <stdio.h>

/*Functions for testing trees. Note that Preorder, Inorder, and Postorder must be tested manually*/
void testTree(BSTree tree);

/*Menu that can be used for testing functions. Of course you can write your version.*/ 
void menuTree(BSTree tree);


int main(void)
{
    BSTree tree = emptyTree();
    
	//testTree(tree);
	//menuTree(tree);
    
    return 0;
}


void testTree(BSTree tree)
{
    printf("Starting test\n");
    
    //Trees are empty in the beginning
    assert(isEmpty(tree));
    
    
    //Insert 7 elements into the tree
    int arr[7] = {5,10,1,3,7,19,16}, i;
    for (i = 0; i < 7; i++)
    {
        insertSorted(&tree, arr[i]);
    }
    
    //Verify that all elements are in the tree
    for (i = 0; i < 7; i++)
    {
        assert(find(tree, arr[i]));
    }
    
    assert(numberOfNodes(tree) == 7);
    assert(depth(tree) == 4); // If we enter the nodes in this order, the depth becomes 4
    assert(minDepth(tree) == 3); // With 7 nodes the minimum depth is 3
    
    removeElement(&tree, 7); // Remove a leaf
    removeElement(&tree, 19); // Remove a node with one child
    removeElement(&tree, 5); // Remove a node with two children
    assert(numberOfNodes(tree) == 4); // Three nodes have been removed
    // Verify that the numbers have been deleted
    assert(!find(tree, 7));
    assert(!find(tree, 19));
    assert(!find(tree, 5));
    
    // Remove the remaining nodes from the tree
    removeElement(&tree, 10);
    removeElement(&tree, 1);
    removeElement(&tree, 3);
    removeElement(&tree, 16);
    
    assert(isEmpty(tree));
    
    // Add in an empty trash
    insertSorted(&tree, 10);
    assert(find(tree, 10));
    
    // Add 9 elements so that the tree is unbalanced
    for (i = 0; i < 9; i++)
        insertSorted(&tree, i+20);
    
    assert(numberOfNodes(tree) == 10);
    
    //Verify that the tree is unbalanced
    assert(depth(tree) != minDepth(tree));
    
    balanceTree(&tree);
    assert(numberOfNodes(tree) == 10); // Verify that the number of nodes is the same
    assert(depth(tree) == minDepth(tree)); // Verify that the tree are balanced
    
    // Empty the tree and verify that it is empty
    freeTree(&tree);
    assert(isEmpty(tree));
    assert(numberOfNodes(tree) == 0);
    assert(depth(tree) == 0);
    
    printf("Congratulations, your program passet the test\n");
}


void menuTree(BSTree tree)
{
    int choice, data;
    char c;
    
    do
    {
        printf("\n\n--------------MENU--------------\n"
               "1 - Add to tree\n"
               "2 - Remove from tree\n"
               "3 - Print in preorder\n"
               "4 - Print in inorder\n"
               "5 - Print in preorder\n"
               "6 - Number of nodes in tree\n"
               "7 - Depth of tree (actual and theoretical)\n"
               "8 - Is the tree empty?\n"
               "9 - Balance tree\n"
               "10 - Search in tree\n"
               "11 - End program\n"
               "-----------------------------------\n"
               "Choice: ");
        
        scanf("%d", &choice);
        while((c = getchar()) != '\n' && c != EOF); // Clears the read buffer
        
        switch(choice)
        {
            case 1: printf("Data to add: ");
                scanf("%d", &data);
                insertSorted(&tree, data);
                printf("Tree: ");
                printPreorder(tree, stdout);
                break;
            case 2: printf("Data to remove: ");
                scanf("%d", &data);
                removeElement(&tree, data);
                printf("Tree: ");
                printPreorder(tree, stdout);
                break;
            case 3: printf("Tree in preorder: ");
                printPreorder(tree, stdout);
                break;
            case 4: printf("Tree in inorder: ");
                printInorder(tree, stdout);
                break;
            case 5: printf("Tree in postorder: ");
                printPostorder(tree, stdout);
                break;
            case 6: printf("Number of nodes in tree: %d", numberOfNodes(tree));
                break;
            case 7: printf("Actual depth of tree: %d\n", depth(tree));
                printf("Theoretical minimum depth of tree: %d\n", minDepth(tree));
            case 8: if (isEmpty(tree) == 1)
                printf("The tree is empty\n");
            else
                printf("The tree is not empty\n");
                
                break;
            case 9: balanceTree(&tree);
                break;
            case 10: printf("Data to search for: ");
                scanf("%d", &data);
                if (find(tree, data) == 1)
                    printf("%d was found in the tree", data);
                else
                    printf("%d was not found in the tree", data);
                
                break;
            case 11: printf("Ending tree menu\n"); break;
            default: printf("Wrong input\n");
        }
        
    }while(choice != 11);
    
}

