#ifndef STATISTICS_H
#define STATISTICS_H
#include <stdio.h>

/********************************************************
   
   DVA104, Lab 5, Statistics.h
 Includes functions to find out statistics on how many
 bytes and comparison you make in sorting algorithms.

*********************************************************/

struct statistics
{
	unsigned int comparisons;
	unsigned int swaps;
};

typedef struct statistics Statistics;

// Reset the data in statistics
void resetStatistics(Statistics* statistics);

// Print the statistics to a file
void printStatistics(const Statistics* statistics, FILE* file);

// comparison operator for the statistics
int lessThan(unsigned int element1, unsigned int element2, Statistics* statistics); // true if element1 < element2
int greaterThan(unsigned int element1, unsigned int element2, Statistics* statistics); // true if element1 > element2
int equalTo(unsigned int element1, unsigned int element2, Statistics* statistics); // true if element1 == element2
int notEqualTo(unsigned int element1, unsigned int element2, Statistics* statistics); // true if element1 != element2
int lessThanOrEqualTo(unsigned int element1, unsigned int element2, Statistics* statistics); // true if element1 <= element2
int greaterThanOrEqualTo(unsigned int element1, unsigned int element2, Statistics* statistics); // true if element >= element2

// Changes location on element1 and element2 in statistics
void swapElements(unsigned int* element1, unsigned int* element2, Statistics* statistics);

#endif
