#ifndef ARRAY_H
#define ARRAY_H
#include <stdlib.h>
#include <stdio.h>

/********************************************************

DVA104, Lab 5, Array.h
Includes features for managing dynamic arrays.

*********************************************************/
// This gives us the unsorted array each time, To enable us to easily compare. You can change this to anything if you want
#define SEED 245802

typedef unsigned int ElementType;

// Decide whether "array" is sorted or not
int isSorted(const ElementType* array, size_t size);

// Creates sorted/unsorted arrays of given size
// Note that these arrays are dynamically allocated and that the memory needs to be released when you finish using them
ElementType* createForwardSortedArray(size_t size);
ElementType* createBackwardSortedArray(size_t size);
ElementType* createUnsortedArray(size_t size);

// Prints an array to file
void printArray(const ElementType* array, size_t size, FILE* file);



#endif
