#ifndef SORTING_ALGORITHMS_H
#define SORTING_ALGORITHMS_H

#include<stdlib.h>
#include<stdio.h>
#include "Statistics.h"

#define NUMBER_OF_SIZES 3 // How many sizes we want to sort

typedef enum { BUBBLE_SORT, SELECTION_SORT, INSERTION_SORT, MERGE_SORT, QUICK_SORT, SORTING_ALGORITHMS } SortingAlgorithm;
typedef unsigned int ElementType;

// Contains all the information needed to sort an array and provide statistics
typedef struct
{
	SortingAlgorithm algorithm;
	ElementType* arrayToSort;
	unsigned int arraySize;
	Statistics statistics;
} SortingArray;

// Returns the name of the algorithm
char* getAlgorithmName(SortingAlgorithm algorithm);

// Sorts and prints statistics for an array of arrays
void sortAndPrint(SortingArray sortingArray[], SortingAlgorithm algorithm, const ElementType* arrays[], unsigned int sizes[], FILE* file);

// Returns 1 if the specified algorithm is implemented, 0 otherwise
int isImplemented(SortingAlgorithm algorithm);

// Release memory for an array of arrays
void freeArray(SortingArray array[]);
#endif

