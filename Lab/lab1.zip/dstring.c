#include "dstring.h"
#include "strtools.h"
#include <stdlib.h>
#include <assert.h>

/* Preconditions and Postconditions are tested with assert()*/

DString createDString(const char* str) {
	// Returns a new DString storing the C string str.
	// Precondition: check that str is not NULL
	// Postcondition: returned string is equal to 'str'

	/* Tips:
	   - allocate the proper amount of memory for storing str and the char for ending a string '\0'.
	   - useful C functions: malloc,strcpy,strlen.
	*/
	return NULL;
}

DString mergeDString(DString front, DString tail) {
	// Returns a new DString storing the C string front followed by tail.
	// Precondition: front is not  NULL
	// Precondition: tail is not  NULL
	// Postcondition: destination stores the front+tail

	return NULL;
}

void shrinkDString(DString* str, char ch) {
	// Shrinks the DString *str up to the first occurence of ch.
	// Precondition: str is not NULL
	// Precondition: *str is not NULL
	// Postcondition: if str has been truncated, its new length corresponds to the position of ch in the original str

	/* Tips:
		- think that str is already allocated in memory and may be changed! Only the proper amount of memory for storing the truncated string is allocated when the function return
	   - do not forget the char for ending a string '\0'
		- useful C functions: realloc.
	*/
}

void displayDString(DString str) {
	// Prints the DString str
	// Precondition: str is not NULL
}

void deleteDString(DString* str) {
	// Releases the memory allocated by *str and sets it to NULL.
	// Precondition: str is NULL
	// Postcondition: *str is NULL when the function ends
}
