#include <assert.h>
#include <stdio.h>
#include "dstring.h"
#include "strtools.h"

#include <string.h>

/* Test for the 'DString' ADT */

int main() {

	/* initialize 2 strings */
	DString str1 = createDString("Hello ");
	DString str2 = createDString("World!");


	/* If any of these fail, your implementation is wrong */
	assert(str1!=NULL && _strlen(str1)==6);
	assert(str2!=NULL && _strlen(str2)==6);

	DString str3 = mergeDString(str1, str2); //merge str1 and str2 in str3, result is "Hello World!"

	/* If any of these fail, your implementation is wrong */
	assert(_strlen(str3)==12);

	/* print "Hello World!" on the screen */
	displayDString(str3);	// print "Hello World!"
	shrinkDString(&str3, ' ');	// truncate str3 after the blank, only "Hello" remains
	shrinkDString(&str3, ' ');	// nothing happens, "Hello" remains the same
	displayDString(str3);	// print "Hello"

	/* If it fails, your implementation is wrong */
	assert(_strlen(str3)==5);

	/* Release the dynamically allocated memory for the strings */
	deleteDString(&str1);
	deleteDString(&str2);
	deleteDString(&str3);

	/* If any of these fail, your implementation is wrong */
	assert(str1 == NULL);
	assert(str2 == NULL);
	assert(str3 == NULL);

	return 0;
}
