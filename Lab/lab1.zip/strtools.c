#include "strtools.h"

int _strlen(const char * str) {
	int i, counter = 0;
	if(str) for (i=0; str[i]!='\0'; ++i) ++counter;
	return counter;
};

void _strcpy(char * dst, const char * src) {
	int i;
	for (i=0; src[i]!='\0'; ++i) dst[i] = src[i];
	dst[i] = '\0';
};

int _strcmp(const char * str1, const char * str2) {
	int i;
	for (i=0; str1[i]!='\0' && str2[i]!='\0'; ++i) if(str1[i]!=str2[i]) return 1;
	return 0;
};

int _strncmp(const char * dst, const char * src, int n) {
	int i;
	for (i=0; i<n; ++i) if(dst[i]!=src[i]) return 1;
	return 0;
};

int _strchr(char * str, char ch) {
	int i;
	for (i=0; str[i]!='\0'; ++i) if(str[i]==ch) return i;
	return -1;
};
