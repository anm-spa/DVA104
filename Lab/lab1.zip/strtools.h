#ifndef STRTOOLS_H
#define STRTOOLS_H

//Returns the length of the C string str.
int _strlen(const char * str);

//Copies the C string pointed by src into the array pointed by dst, including the terminating null character.
void _strcpy(char * dst, const char * src);

//Compares the C string str1 to the C string str2, then it returns 0 is they are equal to each other.
int _strcmp(const char * dst, const char * src);

//Compares the first n characters of the C string str1 to the C string str2, then it returns 0 is they are equal to each other.
int _strncmp(const char * str1, const char * str2, int n);

//Returns the position of the first occurence of ch in the the C string str
int _strchr(char * str, char ch);

#endif
