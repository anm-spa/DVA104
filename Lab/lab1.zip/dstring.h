#ifndef DSTRING_H
#define DSTRING_H

#include <stdlib.h>

typedef char* DString;

DString createDString(const char* str); // Returns a string containing the same text as the str parameter. The returned string is dynamically allocated.

DString mergeDString(DString front, DString tail); //Merger the input strings in a new one, so that the returned string is formed by front followed by tail.

void shrinkDString(DString* str, char ch); //The 'str' string is truncated at the first occurence of the 'ch' char. If 'ch' does not occur in 'str', nothing happens.

void displayDString(DString str); //Print the 'str' string on the display enclosed between two square brackets.

void deleteDString(DString* str); //Release the memory used by 'str' then set it to NULL.

#endif
